﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Vacation
    {
        [ForeignKey(nameof(Id))]
        [Key]
        public Guid Id { get; set; }
        public int StartsAt { get; set; }
        public int EndsAt { get; set; }
    }
}
